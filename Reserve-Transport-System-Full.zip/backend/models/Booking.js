const mongoose = require('mongoose');
const bookingSchema = new mongoose.Schema({
    vehicleId: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true },
    name: { type: String, required: true },
    seatsBooked: { type: Number, required: true },
    date: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Booking', bookingSchema);