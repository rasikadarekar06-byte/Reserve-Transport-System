const express = require('express');
const Booking = require('../models/Booking');
const Vehicle = require('../models/Vehicle');
const router = express.Router();
router.get('/', async (req, res) => {
    try { const bookings = await Booking.find().populate('vehicleId'); res.json(bookings); } 
    catch (err) { res.status(500).json({ message: err.message }); }
});
router.post('/', async (req, res) => {
    const { vehicleId, name, seatsBooked } = req.body;
    try {
        const vehicle = await Vehicle.findById(vehicleId);
        if (!vehicle) return res.status(404).json({ message: 'Vehicle not found' });
        if (seatsBooked > vehicle.seats) return res.status(400).json({ message: 'Not enough seats available' });
        const booking = new Booking({ vehicleId, name, seatsBooked });
        await booking.save();
        vehicle.seats -= seatsBooked;
        await vehicle.save();
        res.status(201).json(booking);
    } catch (err) { res.status(500).json({ message: err.message }); }
});
module.exports = router;