import React, { useState, useEffect } from 'react';
import API from '../api';
export default function TransportForm() {
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [name, setName] = useState('');
  const [seats, setSeats] = useState(1);
  useEffect(() => { API.get('/vehicles').then(res => setVehicles(res.data)); }, []);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try { await API.post('/bookings', { vehicleId: selectedVehicle, name, seatsBooked: seats }); alert('Booking successful!'); } 
    catch (err) { alert(err.response.data.message); }
  };
  return (
    <form onSubmit={handleSubmit}>
      <h2>Book Transport</h2>
      <select value={selectedVehicle} onChange={e => setSelectedVehicle(e.target.value)} required>
        <option value=''>Select Vehicle</option>
        {vehicles.map(v => <option key={v._id} value={v._id}>{v.type} - {v.name} (Seats: {v.seats})</option>)}
      </select>
      <input type='text' placeholder='Your Name' value={name} onChange={e => setName(e.target.value)} required />
      <input type='number' placeholder='Seats' value={seats} onChange={e => setSeats(e.target.value)} min='1' required />
      <button type='submit'>Book</button>
    </form>
  );
}