import React, { useEffect, useState } from 'react';
import API from '../api';
export default function BookingList() {
  const [bookings, setBookings] = useState([]);
  useEffect(() => { API.get('/bookings').then(res => setBookings(res.data)); }, []);
  return (
    <div><h2>All Bookings</h2><ul>
      {bookings.map(b => (<li key={b._id}>{b.name} booked {b.seatsBooked} seat(s) in {b.vehicleId.type} - {b.vehicleId.name}</li>))}
    </ul></div>
  );
}