import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import TransportForm from './components/TransportForm';
import BookingList from './components/BookingList';
function App() { return (<Router><Navbar /><Routes><Route path='/' element={<BookingList />} /><Route path='/book' element={<TransportForm />} /></Routes></Router>); }
export default App;